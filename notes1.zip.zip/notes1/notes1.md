#notes 1

## What is Markdown?
Markdown is a lightweight way to format text using simple symbols—like # for headings, * for italics, ** for bold—so it’s easy to write and read, and can be converted into HTML or styled text.

## What is Git?
Git is a tool that tracks changes in files and helps multiple people work on the same project safely.

## What is GitHub?
It stores your code online Lets you share it with others Helps teams collaborate using Git Tracks changes, handles updates, and manages versions

## What is Slack?
Slack is a messaging app for teams. It lets people: Chat in channels (group topics) or direct messages Share files, images, and links Integrate with other apps like Google Drive, GitHub, and Zoom