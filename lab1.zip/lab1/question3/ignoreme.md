![ignore me](https://assets.midnightcheese.com/gifs/ignore-me.gif)


# Todo list for today
1. clean the house
2. do the dishes 
3. do excercise
4. go visit family
5. watch netflix show

## Shopping list
* tomatoes
* potatoes
* onion
* meat

+ carrot
+ peas

